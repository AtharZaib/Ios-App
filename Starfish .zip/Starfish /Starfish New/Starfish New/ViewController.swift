//
//  ViewController.swift
//  Starfish New
//
//  Created by NAVTTC Students on 01/10/2018.
//  Copyright © 2018 NAVTTC Students. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
  
    @IBOutlet weak var darkBlueBG: UIImageView!
    
    @IBOutlet weak var Power: UIButton!
    @IBOutlet weak var CloudHolder: UIView!
    @IBOutlet weak var rocket: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    
    
    var player: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let path = Bundle.main.path(forResource: "hustle-on", ofType: "wav")!
        let url = URL(fileURLWithPath: path)
        do{
            player=try AVAudioPlayer(contentsOf: url)
            player.prepareToPlay()
        
        }
        catch let error as NSError
        {
            print(error.description)
        }
    }
    
    
    @IBAction func Pressed(_ sender: Any) {
        CloudHolder.isHidden=false
        darkBlueBG.isHidden=true
        Power.isHidden=true
        
        player.play()
        
        UIView.animate(withDuration: 2.3, animations: {
            self.rocket.frame=CGRect(x: 0, y: 140, width: 375, height: 294)
        }) { (finished) in
            self.lbl.isHidden=false;
        }
    }
}
    
    



